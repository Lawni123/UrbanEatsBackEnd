package com.urbanEats.util;

public class AppProperties {
	   public static final String CLOUDINARY_CLOUD_NAME ="dwflwdq1s";
	   public static final String CLOUDINARY_API_KEY="144727916647586";
	   public static final String CLOUDINARY_SECRET_KEY="rAB6hTMl5E9Y_vmPpicBh49-Nu4";
}
