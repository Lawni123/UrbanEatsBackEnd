package com.urbanEats.enums;

public enum PaymentStatus {
	SUCCESS,
	FAILED,
	PENDING
}
