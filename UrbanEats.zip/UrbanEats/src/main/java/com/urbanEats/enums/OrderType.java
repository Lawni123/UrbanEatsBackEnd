package com.urbanEats.enums;

public enum OrderType {
	 DINE_IN,
	 TAKEAWAY
}
