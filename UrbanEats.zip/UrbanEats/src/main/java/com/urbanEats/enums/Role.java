package com.urbanEats.enums;

public enum Role {
	CUSTOMER,
    ADMIN,
    KITCHEN
}
