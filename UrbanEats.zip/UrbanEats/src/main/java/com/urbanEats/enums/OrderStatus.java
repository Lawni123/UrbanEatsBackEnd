package com.urbanEats.enums;

public enum OrderStatus {
	CONFIRMED,
	PREPARING,
	SERVED,
	CANCELLED,
	UNPAID, PREPARED
}
