package com.urbanEats.enums;

public enum PaymentMethod {
	UPI,
	CARD,
	CASH
}
