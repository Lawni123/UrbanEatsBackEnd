package com.urbanEats.enums;

public enum FoodType {
    VEG,
    NON_VEG
}
