package com.burgerAdda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BurgerAddaApplicationTests {

	@Test
	void contextLoads() {
	}

}
